///-----------------------------------------------------------------------///
//fundamentals.mjs
//Simple physics fundamentals helpers
///-----------------------------------------------------------------------///


///-----------------------------------------------------------------------///
//GetAcceleration(mass, force, dt)
//@param mass the mass of the object
//@param force the force to be applied
//@param dt delta time, seconds
//@return the change in velocity
export function GetAcceleration(mass, force, dt = 1)
{
    return (force / mass) * dt;
}
///-----------------------------------------------------------------------///