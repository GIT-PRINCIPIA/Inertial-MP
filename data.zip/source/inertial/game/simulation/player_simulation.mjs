///-----------------------------------------------------------------------///
//player_simulation.mjs
//Handles simulating players. Stateless!
///-----------------------------------------------------------------------///

import { Clamp01, Lerp, SmoothStep } from "../../../utility/scalar.mjs";
import { Vec2 } from "../../../utility/vector.mjs";
import { GetAcceleration } from "../../physics/fundamentals.mjs";
import { GravitySimulation } from "./gravity_simulation.mjs";


///-----------------------------------------------------------------------///
//PlayerSimulation class
export class PlayerSimulation
{
    ///-----------------------------------------------------------------------///
    //UpdatePlayer(player, dt, gameState)
    //@param player the player to update
    //@param dt the timestep, delta time
    //@param gameState the current GameState
    static UpdatePlayer(player, dt, gameState)
    {
        player.pos.AddInPlace(player.vel.MultiplyScalar(dt));
        player.rot += player.angVel * dt;

        {
            let error = player.targetAngVel - player.angVel;

            let impulse = Math.sign(error) * Math.min(Math.abs(error), player.shipConfig.turnAccel * dt);

            player.angVel += impulse;
        }

        for (const NODE of gameState.nodes)
        {
            const DELTA = NODE.pos.Subtract(player.pos);
            const SQR_DIST = DELTA.SqrLength();
            const DELTA_NORM = DELTA.Normalize();
            const ACCELERATIION = GravitySimulation.CalculateAcceleration(SQR_DIST, NODE.mass) * dt;


            const ACCELERATIION_VEC = DELTA_NORM.MultiplyScalar(ACCELERATIION);

            player.vel.AddInPlace(ACCELERATIION_VEC);
        }
        player.targetAngVel = 0;
    }
    ///-----------------------------------------------------------------------///


    ///-----------------------------------------------------------------------///
    //ApplyPlayerInput(player, input, dt)
    //@param player the player to apply input to
    //@param input the input
    //@param dt delta time
    static ApplyPlayerInput(player, input, dt)
    {
        switch (input)
        {
            case "W":
            {
                let dirVec = Vec2.FromAngle(player.rot);
                let accel = GetAcceleration(player.shipConfig.mass, player.shipConfig.forwardThrustForce, dt);
                dirVec.MultiplyScalarInPlace(accel);
                player.vel.AddInPlace(dirVec);
            }
            break;
            case "S":
            {
                let dirVec = Vec2.FromAngle(player.rot);
                let accel = GetAcceleration(player.shipConfig.mass, player.shipConfig.backwardThrustForce, dt);
                dirVec.MultiplyScalarInPlace(-accel); //Backwards
                player.vel.AddInPlace(dirVec);
            }
            break;
            case "A":
            {
                player.targetAngVel = -player.shipConfig.turnSpeed;
            }
            break;
            case "D":
            {
                player.targetAngVel = player.shipConfig.turnSpeed;
            }
            break;
        }
    }
    ///-----------------------------------------------------------------------///
}
//End of PlayerSimulation class
///-----------------------------------------------------------------------///